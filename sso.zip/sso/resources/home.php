<?php
    // PHP code can be placed here, if needed
?>
<!DOCTYPE html>
<html>
<head>
    <title>Logged In Successfully</title>
</head>
<body>
    <h1>You are logged in successfully</h1>
</body>
</html>